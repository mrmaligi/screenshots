-- =============================================================================
-- AUSTRALIAN VISA APPLICATION TRACKING SaaS - DATABASE SCHEMA
-- PostgreSQL 14+ Compatible
-- =============================================================================
-- Author: Database Architect
-- Purpose: Enterprise-grade schema for visa application lifecycle management
-- =============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =============================================================================
-- 1. USERS TABLE
-- Purpose: Core user accounts with authentication and profile information
-- =============================================================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    phone VARCHAR(20),
    mobile VARCHAR(20),
    country_of_birth VARCHAR(100),
    country_of_citizenship VARCHAR(100),
    current_country VARCHAR(100),
    preferred_language VARCHAR(10) DEFAULT 'en',
    timezone VARCHAR(50) DEFAULT 'Australia/Sydney',
    email_verified BOOLEAN DEFAULT FALSE,
    email_verified_at TIMESTAMPTZ,
    phone_verified BOOLEAN DEFAULT FALSE,
    mfa_enabled BOOLEAN DEFAULT FALSE,
    mfa_secret VARCHAR(255),
    avatar_url TEXT,
    account_status VARCHAR(20) DEFAULT 'active' CHECK (account_status IN ('active', 'suspended', 'deactivated', 'pending')),
    last_login_at TIMESTAMPTZ,
    login_count INTEGER DEFAULT 0,
    marketing_consent BOOLEAN DEFAULT FALSE,
    terms_accepted_at TIMESTAMPTZ,
    privacy_accepted_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE users IS 'Core user accounts with authentication and profile information';
COMMENT ON COLUMN users.account_status IS 'User account status: active, suspended, deactivated, pending';

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_status ON users(account_status) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_created_at ON users(created_at);

-- =============================================================================
-- 2. VISA_CATALOGUE TABLE
-- Purpose: Master list of all Australian visa subclasses with fees and flags
-- =============================================================================
CREATE TABLE visa_catalogue (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visa_subclass VARCHAR(10) NOT NULL UNIQUE,
    visa_name VARCHAR(255) NOT NULL,
    visa_stream VARCHAR(100),
    visa_category VARCHAR(50) NOT NULL CHECK (visa_category IN ('skilled', 'family', 'business', 'student', 'visitor', 'work', 'other')),
    description TEXT,
    base_application_fee_aud DECIMAL(10,2),
    additional_applicant_fee_aud DECIMAL(10,2),
    secondary_applicant_fee_aud DECIMAL(10,2),
    requires_sponsorship BOOLEAN DEFAULT FALSE,
    requires_nomination BOOLEAN DEFAULT FALSE,
    requires_skills_assessment BOOLEAN DEFAULT FALSE,
    requires_english_test BOOLEAN DEFAULT FALSE,
    requires_health_exam BOOLEAN DEFAULT FALSE,
    requires_police_clearance BOOLEAN DEFAULT FALSE,
    points_tested BOOLEAN DEFAULT FALSE,
    minimum_points_required INTEGER DEFAULT 0,
    age_limit INTEGER,
    processing_time_min_days INTEGER,
    processing_time_max_days INTEGER,
    is_active BOOLEAN DEFAULT TRUE,
    department_url TEXT,
    document_checklist JSONB,
    eligibility_criteria JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE visa_catalogue IS 'Master list of all Australian visa subclasses with fees and requirements';
COMMENT ON COLUMN visa_catalogue.visa_subclass IS 'Official visa subclass number (e.g., 189, 190, 491)';
COMMENT ON COLUMN visa_catalogue.points_tested IS 'Whether visa requires points test (e.g., 189, 190, 491)';

CREATE INDEX idx_visa_subclass ON visa_catalogue(visa_subclass);
CREATE INDEX idx_visa_category ON visa_catalogue(visa_category);
CREATE INDEX idx_visa_active ON visa_catalogue(is_active);
CREATE INDEX idx_visa_points_tested ON visa_catalogue(points_tested) WHERE points_tested = TRUE;

-- =============================================================================
-- 3. ANZSCO_MASTER_LIST TABLE
-- Purpose: Complete ANZSCO occupations with codes, titles, and assessing authorities
-- =============================================================================
CREATE TABLE anzsco_master_list (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    anzsco_code VARCHAR(6) NOT NULL UNIQUE,
    occupation_title VARCHAR(255) NOT NULL,
    occupation_description TEXT,
    skill_level VARCHAR(10) CHECK (skill_level IN ('1', '2', '3', '4', '5')),
    major_group VARCHAR(10),
    sub_major_group VARCHAR(10),
    minor_group VARCHAR(10),
    unit_group VARCHAR(10),
    assessing_authority VARCHAR(100),
    assessing_authority_code VARCHAR(20),
    assessing_authority_url TEXT,
    on_mltssl BOOLEAN DEFAULT FALSE,
    on_stsol BOOLEAN DEFAULT FALSE,
    on_rol BOOLEAN DEFAULT FALSE,
    on_pmsol BOOLEAN DEFAULT FALSE,
    on_core_skills_list BOOLEAN DEFAULT FALSE,
    caveats TEXT,
    alternative_titles JSONB,
    specialisations JSONB,
    nec_occupation BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    effective_from DATE,
    effective_to DATE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE anzsco_master_list IS 'Complete ANZSCO occupations with codes, titles, and assessing authorities';
COMMENT ON COLUMN anzsco_master_list.on_mltssl IS 'Medium and Long-term Strategic Skills List';
COMMENT ON COLUMN anzsco_master_list.on_stsol IS 'Short-term Skilled Occupation List';
COMMENT ON COLUMN anzsco_master_list.on_rol IS 'Regional Occupation List';
COMMENT ON COLUMN anzsco_master_list.on_pmsol IS 'Priority Migration Skilled Occupation List';

CREATE INDEX idx_anzsco_code ON anzsco_master_list(anzsco_code);
CREATE INDEX idx_anzsco_title ON anzsco_master_list(occupation_title);
CREATE INDEX idx_anzsco_mltssl ON anzsco_master_list(on_mltssl) WHERE on_mltssl = TRUE;
CREATE INDEX idx_anzsco_stsol ON anzsco_master_list(on_stsol) WHERE on_stsol = TRUE;
CREATE INDEX idx_anzsco_rol ON anzsco_master_list(on_rol) WHERE on_rol = TRUE;
CREATE INDEX idx_anzsco_pmsol ON anzsco_master_list(on_pmsol) WHERE on_pmsol = TRUE;
CREATE INDEX idx_anzsco_skill_level ON anzsco_master_list(skill_level);
CREATE INDEX idx_anzsco_authority ON anzsco_master_list(assessing_authority);

-- =============================================================================
-- 4. POINTS_COMPONENTS TABLE (Lookup)
-- Purpose: Lookup table for points categories and their possible values
-- =============================================================================
CREATE TABLE points_components (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    component_code VARCHAR(50) NOT NULL UNIQUE,
    component_name VARCHAR(100) NOT NULL,
    component_category VARCHAR(50) NOT NULL CHECK (component_category IN ('age', 'english', 'experience', 'education', 'australian_study', 'regional', 'partner', 'other')),
    description TEXT,
    min_points INTEGER DEFAULT 0,
    max_points INTEGER,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE points_components IS 'Lookup table for points test categories and their possible values';

CREATE INDEX idx_points_component_code ON points_components(component_code);
CREATE INDEX idx_points_category ON points_components(component_category);

-- =============================================================================
-- 5. POINTS_COMPONENT_VALUES TABLE
-- Purpose: Specific point values for each component criterion
-- =============================================================================
CREATE TABLE points_component_values (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    component_id UUID NOT NULL REFERENCES points_components(id) ON DELETE CASCADE,
    criterion_description VARCHAR(255) NOT NULL,
    criterion_value VARCHAR(100),
    points_awarded INTEGER NOT NULL,
    min_threshold VARCHAR(100),
    max_threshold VARCHAR(100),
    effective_from DATE DEFAULT CURRENT_DATE,
    effective_to DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE points_component_values IS 'Specific point values for each points test criterion';

CREATE INDEX idx_points_value_component ON points_component_values(component_id);
CREATE INDEX idx_points_value_active ON points_component_values(is_active);

-- =============================================================================
-- 6. POINTS_CALCULATOR TABLE
-- Purpose: Granular tracking for user points across all categories
-- =============================================================================
CREATE TABLE points_calculator (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    visa_subclass_id UUID REFERENCES visa_catalogue(id),
    
    -- Age Points
    age INTEGER,
    age_points INTEGER DEFAULT 0,
    
    -- English Language Points
    english_test_type VARCHAR(50),
    english_overall_score DECIMAL(3,1),
    english_listening_score DECIMAL(3,1),
    english_reading_score DECIMAL(3,1),
    english_writing_score DECIMAL(3,1),
    english_speaking_score DECIMAL(3,1),
    english_points INTEGER DEFAULT 0,
    english_test_date DATE,
    english_test_expiry DATE,
    
    -- Overseas Work Experience Points
    overseas_experience_years DECIMAL(4,1),
    overseas_experience_points INTEGER DEFAULT 0,
    
    -- Australian Work Experience Points
    australian_experience_years DECIMAL(4,1),
    australian_experience_points INTEGER DEFAULT 0,
    
    -- Education Points
    highest_qualification VARCHAR(100),
    qualification_level VARCHAR(50),
    qualification_australian BOOLEAN DEFAULT FALSE,
    education_points INTEGER DEFAULT 0,
    
    -- Australian Study Points
    australian_study_qualification VARCHAR(100),
    australian_study_years DECIMAL(3,1),
    australian_study_points INTEGER DEFAULT 0,
    
    -- Regional Study Points
    regional_study_location VARCHAR(100),
    regional_study_points INTEGER DEFAULT 0,
    
    -- Professional Year Points
    professional_year_completed BOOLEAN DEFAULT FALSE,
    professional_year_field VARCHAR(100),
    professional_year_points INTEGER DEFAULT 0,
    
    -- Credentialled Community Language (CCL) Points
    ccl_completed BOOLEAN DEFAULT FALSE,
    ccl_language VARCHAR(50),
    ccl_points INTEGER DEFAULT 0,
    
    -- Partner Points
    partner_skill_status VARCHAR(50),
    partner_english_competent BOOLEAN DEFAULT FALSE,
    partner_points INTEGER DEFAULT 0,
    
    -- State Nomination Points
    state_nomination_points INTEGER DEFAULT 0,
    
    -- Total Points
    total_points INTEGER DEFAULT 0,
    calculated_at TIMESTAMPTZ,
    is_current BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE points_calculator IS 'Granular tracking for user points across all visa points test categories';
COMMENT ON COLUMN points_calculator.english_test_type IS 'IELTS, PTE, TOEFL, OET, Cambridge';

CREATE INDEX idx_points_user ON points_calculator(user_id);
CREATE INDEX idx_points_visa ON points_calculator(visa_subclass_id);
CREATE INDEX idx_points_current ON points_calculator(is_current) WHERE is_current = TRUE;
CREATE INDEX idx_points_total ON points_calculator(total_points);
CREATE INDEX idx_points_calculated_at ON points_calculator(calculated_at);

-- =============================================================================
-- 7. APPLICATION_STAGES TABLE
-- Purpose: Template stages/timeline steps for each visa type
-- =============================================================================
CREATE TABLE application_stages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visa_subclass_id UUID NOT NULL REFERENCES visa_catalogue(id) ON DELETE CASCADE,
    stage_code VARCHAR(50) NOT NULL,
    stage_name VARCHAR(100) NOT NULL,
    stage_description TEXT,
    stage_order INTEGER NOT NULL,
    estimated_duration_days INTEGER,
    is_mandatory BOOLEAN DEFAULT TRUE,
    requires_document_upload BOOLEAN DEFAULT FALSE,
    requires_payment BOOLEAN DEFAULT FALSE,
    requires_appointment BOOLEAN DEFAULT FALSE,
    stage_category VARCHAR(50) CHECK (stage_category IN ('preparation', 'submission', 'assessment', 'decision', 'post_decision')),
    checklist_items JSONB,
    department_stage_name VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(visa_subclass_id, stage_code)
);

COMMENT ON TABLE application_stages IS 'Template stages and timeline steps for each visa subclass';

CREATE INDEX idx_stages_visa ON application_stages(visa_subclass_id);
CREATE INDEX idx_stages_order ON application_stages(visa_subclass_id, stage_order);
CREATE INDEX idx_stages_category ON application_stages(stage_category);
CREATE INDEX idx_stages_active ON application_stages(is_active);

-- =============================================================================
-- 8. USER_JOURNEYS TABLE
-- Purpose: Maps users to their visa applications, tracks progress and status
-- =============================================================================
CREATE TABLE user_journeys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    visa_subclass_id UUID NOT NULL REFERENCES visa_catalogue(id),
    anzsco_occupation_id UUID REFERENCES anzsco_master_list(id),
    
    -- Application Identifiers
    application_reference VARCHAR(50),
    immiaccount_reference VARCHAR(50),
    trn_number VARCHAR(20),
    
    -- Application Status
    application_status VARCHAR(50) DEFAULT 'draft' CHECK (application_status IN ('draft', 'in_progress', 'submitted', 'under_assessment', 'additional_documents_requested', 'interview_scheduled', 'health_check_required', 'pending_decision', 'approved', 'refused', 'withdrawn', 'on_hold')),
    
    -- Key Dates
    journey_started_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    submitted_at TIMESTAMPTZ,
    decision_date DATE,
    decision_expiry_date DATE,
    visa_grant_number VARCHAR(50),
    
    -- Points Information
    claimed_points INTEGER DEFAULT 0,
    invited_points INTEGER,
    invitation_date DATE,
    
    -- Nomination/Sponsorship
    nominated_by_state VARCHAR(50),
    nominated_by_employer VARCHAR(255),
    nomination_status VARCHAR(50),
    nomination_expiry DATE,
    
    -- Current Stage
    current_stage_id UUID REFERENCES application_stages(id),
    current_stage_started_at TIMESTAMPTZ,
    overall_progress_percent INTEGER DEFAULT 0 CHECK (overall_progress_percent >= 0 AND overall_progress_percent <= 100),
    
    -- Priority and Flags
    priority_processing BOOLEAN DEFAULT FALSE,
    priority_processing_reason VARCHAR(100),
    
    -- Notes and Metadata
    notes TEXT,
    metadata JSONB,
    
    -- Soft Delete
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE user_journeys IS 'Maps users to their visa applications, tracking progress and status throughout the lifecycle';
COMMENT ON COLUMN user_journeys.application_status IS 'Current status of the visa application in the lifecycle';

CREATE INDEX idx_journeys_user ON user_journeys(user_id);
CREATE INDEX idx_journeys_visa ON user_journeys(visa_subclass_id);
CREATE INDEX idx_journeys_status ON user_journeys(application_status);
CREATE INDEX idx_journeys_reference ON user_journeys(application_reference);
CREATE INDEX idx_journeys_active ON user_journeys(deleted_at) WHERE deleted_at IS NULL;
CREATE INDEX idx_journeys_occupation ON user_journeys(anzsco_occupation_id);
CREATE INDEX idx_journeys_invitation ON user_journeys(invitation_date);

-- =============================================================================
-- 9. DOCUMENT_VAULT TABLE
-- Purpose: Document checklists, upload tracking, expiry dates
-- =============================================================================
CREATE TABLE document_vault (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_code VARCHAR(50) NOT NULL UNIQUE,
    document_name VARCHAR(255) NOT NULL,
    document_category VARCHAR(50) NOT NULL CHECK (document_category IN ('identity', 'passport', 'birth', 'relationship', 'employment', 'education', 'financial', 'health', 'character', 'english', 'skills_assessment', 'nomination', 'other')),
    document_description TEXT,
    
    -- Requirements
    is_mandatory BOOLEAN DEFAULT FALSE,
    requires_certified_copy BOOLEAN DEFAULT FALSE,
    requires_translation BOOLEAN DEFAULT FALSE,
    requires_apostille BOOLEAN DEFAULT FALSE,
    
    -- File Specifications
    allowed_file_types JSONB DEFAULT '["pdf", "jpg", "jpeg", "png"]',
    max_file_size_mb INTEGER DEFAULT 10,
    
    -- Expiry Tracking
    has_expiry_date BOOLEAN DEFAULT FALSE,
    expiry_warning_days INTEGER DEFAULT 30,
    validity_period_months INTEGER,
    
    -- Applicability
    applicable_visa_subclasses JSONB,
    applicable_nationalities JSONB,
    
    -- Instructions
    upload_instructions TEXT,
    department_requirements TEXT,
    
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE document_vault IS 'Master document checklist with requirements and specifications';
COMMENT ON COLUMN document_vault.document_category IS 'Category of document for organizing requirements';

CREATE INDEX idx_doc_vault_code ON document_vault(document_code);
CREATE INDEX idx_doc_vault_category ON document_vault(document_category);
CREATE INDEX idx_doc_vault_mandatory ON document_vault(is_mandatory);
CREATE INDEX idx_doc_vault_expiry ON document_vault(has_expiry_date) WHERE has_expiry_date = TRUE;

-- =============================================================================
-- 10. USER_VISA_DOCUMENTS TABLE (Junction)
-- Purpose: Links users to required documents for their specific visa applications
-- =============================================================================
CREATE TABLE user_visa_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    journey_id UUID NOT NULL REFERENCES user_journeys(id) ON DELETE CASCADE,
    document_vault_id UUID NOT NULL REFERENCES document_vault(id),
    
    -- Upload Information
    file_name VARCHAR(255),
    file_path TEXT,
    file_size_bytes BIGINT,
    file_mime_type VARCHAR(100),
    file_hash VARCHAR(64),
    
    -- Document Status
    upload_status VARCHAR(50) DEFAULT 'pending' CHECK (upload_status IN ('pending', 'uploaded', 'under_review', 'approved', 'rejected', 'expired')),
    
    -- Expiry Tracking
    issue_date DATE,
    expiry_date DATE,
    days_until_expiry INTEGER GENERATED ALWAYS AS (
        CASE 
            WHEN expiry_date IS NOT NULL THEN (expiry_date - CURRENT_DATE)::INTEGER
            ELSE NULL
        END
    ) STORED,
    
    -- Review Information
    uploaded_at TIMESTAMPTZ,
    reviewed_at TIMESTAMPTZ,
    reviewed_by UUID REFERENCES users(id),
    review_notes TEXT,
    rejection_reason TEXT,
    
    -- Version Control
    version_number INTEGER DEFAULT 1,
    previous_version_id UUID REFERENCES user_visa_documents(id),
    
    -- Metadata
    metadata JSONB,
    
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE user_visa_documents IS 'Junction table linking users to required documents for their visa applications';
COMMENT ON COLUMN user_visa_documents.upload_status IS 'Current status of the document upload';

CREATE INDEX idx_user_docs_user ON user_visa_documents(user_id);
CREATE INDEX idx_user_docs_journey ON user_visa_documents(journey_id);
CREATE INDEX idx_user_docs_vault ON user_visa_documents(document_vault_id);
CREATE INDEX idx_user_docs_status ON user_visa_documents(upload_status);
CREATE INDEX idx_user_docs_expiry ON user_visa_documents(expiry_date) WHERE expiry_date IS NOT NULL;
CREATE INDEX idx_user_docs_expiring ON user_visa_documents(days_until_expiry) WHERE days_until_expiry <= 30 AND days_until_expiry >= 0;

-- =============================================================================
-- 11. VISA_REQUIREMENTS TABLE
-- Purpose: Specific requirements per visa subclass
-- =============================================================================
CREATE TABLE visa_requirements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visa_subclass_id UUID NOT NULL REFERENCES visa_catalogue(id) ON DELETE CASCADE,
    requirement_code VARCHAR(50) NOT NULL,
    requirement_name VARCHAR(255) NOT NULL,
    requirement_description TEXT,
    requirement_type VARCHAR(50) CHECK (requirement_type IN ('age', 'english', 'skills', 'health', 'character', 'financial', 'relationship', 'employment', 'education', 'other')),
    
    -- Requirement Specifications
    is_mandatory BOOLEAN DEFAULT TRUE,
    min_value VARCHAR(100),
    max_value VARCHAR(100),
    acceptable_values JSONB,
    
    -- Documentation
    supporting_documents_required JSONB,
    verification_method VARCHAR(100),
    
    -- Applicability Rules
    applicable_when JSONB,
    exemption_conditions JSONB,
    
    -- External References
    legislation_reference VARCHAR(255),
    policy_reference VARCHAR(255),
    
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    effective_from DATE DEFAULT CURRENT_DATE,
    effective_to DATE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(visa_subclass_id, requirement_code)
);

COMMENT ON TABLE visa_requirements IS 'Specific eligibility requirements for each visa subclass';

CREATE INDEX idx_requirements_visa ON visa_requirements(visa_subclass_id);
CREATE INDEX idx_requirements_type ON visa_requirements(requirement_type);
CREATE INDEX idx_requirements_active ON visa_requirements(is_active);
CREATE INDEX idx_requirements_mandatory ON visa_requirements(is_mandatory) WHERE is_mandatory = TRUE;

-- =============================================================================
-- 12. NOTIFICATIONS TABLE
-- Purpose: User notification tracking
-- =============================================================================
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    journey_id UUID REFERENCES user_journeys(id) ON DELETE CASCADE,
    
    -- Notification Content
    notification_type VARCHAR(50) NOT NULL CHECK (notification_type IN ('system', 'document', 'stage_change', 'payment', 'expiry_warning', 'decision', 'invitation', 'general')),
    priority VARCHAR(20) DEFAULT 'normal' CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    
    -- Action Information
    action_url TEXT,
    action_text VARCHAR(100),
    
    -- Delivery Tracking
    email_sent BOOLEAN DEFAULT FALSE,
    email_sent_at TIMESTAMPTZ,
    push_sent BOOLEAN DEFAULT FALSE,
    push_sent_at TIMESTAMPTZ,
    sms_sent BOOLEAN DEFAULT FALSE,
    sms_sent_at TIMESTAMPTZ,
    
    -- Read Status
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMPTZ,
    
    -- Metadata
    metadata JSONB,
    
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE notifications IS 'User notification tracking for all application events';
COMMENT ON COLUMN notifications.notification_type IS 'Type of notification for categorization';

CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_journey ON notifications(journey_id);
CREATE INDEX idx_notifications_type ON notifications(notification_type);
CREATE INDEX idx_notifications_unread ON notifications(user_id, is_read) WHERE is_read = FALSE;
CREATE INDEX idx_notifications_priority ON notifications(priority);
CREATE INDEX idx_notifications_created ON notifications(created_at DESC);

-- =============================================================================
-- 13. PAYMENT_TRACKING TABLE
-- Purpose: Visa fee payments and history
-- =============================================================================
CREATE TABLE payment_tracking (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    journey_id UUID REFERENCES user_journeys(id) ON DELETE CASCADE,
    
    -- Payment Details
    payment_reference VARCHAR(100) NOT NULL UNIQUE,
    payment_type VARCHAR(50) NOT NULL CHECK (payment_type IN ('application_fee', 'additional_applicant', 'surcharge', 'priority_processing', 'other')),
    payment_description VARCHAR(255),
    
    -- Amount Information
    amount_aud DECIMAL(10,2) NOT NULL,
    gst_amount_aud DECIMAL(10,2) DEFAULT 0,
    total_amount_aud DECIMAL(10,2) NOT NULL,
    currency_code VARCHAR(3) DEFAULT 'AUD',
    exchange_rate DECIMAL(10,6) DEFAULT 1.0,
    
    -- Payment Method
    payment_method VARCHAR(50) CHECK (payment_method IN ('credit_card', 'debit_card', 'bpay', 'paypal', 'bank_transfer', 'immipay')),
    payment_provider VARCHAR(50),
    provider_transaction_id VARCHAR(255),
    
    -- Payment Status
    payment_status VARCHAR(50) DEFAULT 'pending' CHECK (payment_status IN ('pending', 'processing', 'completed', 'failed', 'refunded', 'partially_refunded', 'disputed')),
    
    -- Timestamps
    initiated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ,
    refunded_at TIMESTAMPTZ,
    
    -- Refund Information
    refund_amount_aud DECIMAL(10,2),
    refund_reason TEXT,
    
    -- Receipt
    receipt_number VARCHAR(100),
    receipt_url TEXT,
    
    -- Metadata
    metadata JSONB,
    
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE payment_tracking IS 'Visa fee payments and transaction history';
COMMENT ON COLUMN payment_tracking.payment_status IS 'Current status of the payment transaction';

CREATE INDEX idx_payments_user ON payment_tracking(user_id);
CREATE INDEX idx_payments_journey ON payment_tracking(journey_id);
CREATE INDEX idx_payments_reference ON payment_tracking(payment_reference);
CREATE INDEX idx_payments_status ON payment_tracking(payment_status);
CREATE INDEX idx_payments_type ON payment_tracking(payment_type);
CREATE INDEX idx_payments_completed ON payment_tracking(completed_at);

-- =============================================================================
-- 14. USER_ACTIVITY_LOG TABLE (Audit Trail)
-- Purpose: Comprehensive audit trail for all user actions
-- =============================================================================
CREATE TABLE user_activity_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    journey_id UUID REFERENCES user_journeys(id) ON DELETE SET NULL,
    
    -- Activity Details
    activity_type VARCHAR(50) NOT NULL,
    activity_description TEXT,
    entity_type VARCHAR(50),
    entity_id UUID,
    
    -- Change Tracking
    old_values JSONB,
    new_values JSONB,
    
    -- Context
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(255),
    
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE user_activity_log IS 'Comprehensive audit trail for all user actions and system events';

CREATE INDEX idx_activity_user ON user_activity_log(user_id);
CREATE INDEX idx_activity_journey ON user_activity_log(journey_id);
CREATE INDEX idx_activity_type ON user_activity_log(activity_type);
CREATE INDEX idx_activity_entity ON user_activity_log(entity_type, entity_id);
CREATE INDEX idx_activity_created ON user_activity_log(created_at DESC);

-- =============================================================================
-- 15. SYSTEM_SETTINGS TABLE
-- Purpose: Application configuration and settings
-- =============================================================================
CREATE TABLE system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_type VARCHAR(20) DEFAULT 'string' CHECK (setting_type IN ('string', 'integer', 'boolean', 'json', 'array')),
    description TEXT,
    is_editable BOOLEAN DEFAULT TRUE,
    category VARCHAR(50) DEFAULT 'general',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE system_settings IS 'Application configuration and system settings';

CREATE INDEX idx_settings_key ON system_settings(setting_key);
CREATE INDEX idx_settings_category ON system_settings(category);

-- =============================================================================
-- TRIGGERS FOR UPDATED_AT TIMESTAMP
-- =============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply updated_at trigger to all tables
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_visa_catalogue_updated_at BEFORE UPDATE ON visa_catalogue
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_anzsco_master_list_updated_at BEFORE UPDATE ON anzsco_master_list
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_points_components_updated_at BEFORE UPDATE ON points_components
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_points_component_values_updated_at BEFORE UPDATE ON points_component_values
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_points_calculator_updated_at BEFORE UPDATE ON points_calculator
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_application_stages_updated_at BEFORE UPDATE ON application_stages
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_journeys_updated_at BEFORE UPDATE ON user_journeys
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_document_vault_updated_at BEFORE UPDATE ON document_vault
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_visa_documents_updated_at BEFORE UPDATE ON user_visa_documents
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_visa_requirements_updated_at BEFORE UPDATE ON visa_requirements
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notifications_updated_at BEFORE UPDATE ON notifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payment_tracking_updated_at BEFORE UPDATE ON payment_tracking
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON system_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =============================================================================
-- SEED DATA - Points Components
-- =============================================================================
INSERT INTO points_components (component_code, component_name, component_category, description, min_points, max_points, sort_order) VALUES
('age', 'Age', 'age', 'Points based on age at time of invitation', 0, 30, 1),
('english', 'English Language', 'english', 'Points based on English language proficiency', 0, 20, 2),
('overseas_exp', 'Overseas Work Experience', 'experience', 'Points for skilled employment outside Australia', 0, 15, 3),
('aus_exp', 'Australian Work Experience', 'experience', 'Points for skilled employment in Australia', 0, 20, 4),
('education', 'Education', 'education', 'Points based on highest educational qualification', 0, 20, 5),
('aus_study', 'Australian Study', 'australian_study', 'Points for Australian study qualification', 0, 5, 6),
('regional_study', 'Regional Study', 'regional', 'Points for study in regional Australia', 0, 5, 7),
('professional_year', 'Professional Year', 'australian_study', 'Points for completing Professional Year in Australia', 0, 5, 8),
('ccl', 'Credentialled Community Language', 'other', 'Points for NAATI CCL test', 0, 5, 9),
('partner', 'Partner Skills', 'partner', 'Points for partner skills and qualifications', 0, 10, 10),
('state_nom', 'State/Territory Nomination', 'other', 'Points for state or territory nomination', 0, 15, 11);

-- =============================================================================
-- SEED DATA - Sample Visa Types
-- =============================================================================
INSERT INTO visa_catalogue (visa_subclass, visa_name, visa_stream, visa_category, description, base_application_fee_aud, points_tested, minimum_points_required, requires_skills_assessment, requires_english_test, is_active) VALUES
('189', 'Skilled Independent Visa', NULL, 'skilled', 'Permanent visa for points-tested skilled workers who are not sponsored by an employer or family member or nominated by a state or territory government', 4640.00, TRUE, 65, TRUE, TRUE, TRUE),
('190', 'Skilled Nominated Visa', NULL, 'skilled', 'Permanent visa for points-tested skilled workers who are nominated by an Australian state or territory government agency', 4640.00, TRUE, 65, TRUE, TRUE, TRUE),
('491', 'Skilled Work Regional (Provisional) Visa', NULL, 'skilled', 'Temporary visa for skilled workers who want to live and work in regional Australia', 4640.00, TRUE, 65, TRUE, TRUE, TRUE),
('482', 'Temporary Skill Shortage Visa', NULL, 'work', 'Temporary visa to work in Australia for an approved employer', 1495.00, FALSE, 0, TRUE, TRUE, TRUE),
('186', 'Employer Nomination Scheme', NULL, 'skilled', 'Permanent visa for skilled workers nominated by an Australian employer', 4640.00, FALSE, 0, TRUE, TRUE, TRUE),
('820', 'Partner Visa (Temporary)', NULL, 'family', 'Temporary visa for partners of Australian citizens, permanent residents or eligible New Zealand citizens', 8085.00, FALSE, 0, FALSE, FALSE, TRUE),
('500', 'Student Visa', NULL, 'student', 'Temporary visa to study in Australia', 710.00, FALSE, 0, FALSE, TRUE, TRUE),
('600', 'Visitor Visa', NULL, 'visitor', 'Temporary visa to visit Australia for tourism or business', 190.00, FALSE, 0, FALSE, FALSE, TRUE);

-- =============================================================================
-- SEED DATA - Sample Document Types
-- =============================================================================
INSERT INTO document_vault (document_code, document_name, document_category, is_mandatory, has_expiry_date, validity_period_months, upload_instructions) VALUES
('passport', 'Passport', 'identity', TRUE, TRUE, NULL, 'Upload a clear, color copy of your passport biodata page'),
('birth_cert', 'Birth Certificate', 'identity', TRUE, FALSE, NULL, 'Upload a certified copy of your birth certificate'),
('ielts', 'IELTS Test Result', 'english', TRUE, TRUE, 36, 'Upload your official IELTS test report form'),
('pte', 'PTE Academic Result', 'english', TRUE, TRUE, 36, 'Upload your PTE Academic score report'),
('skills_assessment', 'Skills Assessment', 'skills_assessment', TRUE, TRUE, 36, 'Upload your positive skills assessment letter from the relevant assessing authority'),
('employment_ref', 'Employment Reference', 'employment', TRUE, FALSE, NULL, 'Upload employment reference letters from current and previous employers'),
('police_clearance', 'Police Clearance Certificate', 'character', TRUE, TRUE, 12, 'Upload police clearance certificates from all countries where you have lived for 12+ months in the last 10 years'),
('medical_exam', 'Medical Examination', 'health', TRUE, TRUE, 12, 'Upload your completed health examination results'),
('degree_cert', 'Degree Certificate', 'education', TRUE, FALSE, NULL, 'Upload your degree certificate(s) and academic transcripts'),
('resume_cv', 'Resume/CV', 'employment', TRUE, FALSE, NULL, 'Upload your current resume or curriculum vitae');

-- =============================================================================
-- VIEWS FOR COMMON QUERIES
-- =============================================================================

-- View: Active User Journeys with Details
CREATE VIEW v_active_journeys AS
SELECT 
    uj.id,
    uj.user_id,
    u.email,
    u.first_name || ' ' || u.last_name AS full_name,
    vc.visa_subclass,
    vc.visa_name,
    uj.application_status,
    uj.claimed_points,
    uj.overall_progress_percent,
    uj.journey_started_at,
    uj.submitted_at,
    uj.invitation_date,
    am.anzsco_code,
    am.occupation_title
FROM user_journeys uj
JOIN users u ON uj.user_id = u.id
JOIN visa_catalogue vc ON uj.visa_subclass_id = vc.id
LEFT JOIN anzsco_master_list am ON uj.anzsco_occupation_id = am.id
WHERE uj.deleted_at IS NULL;

COMMENT ON VIEW v_active_journeys IS 'Active user journeys with user and visa details';

-- View: Documents Expiring Soon
CREATE VIEW v_expiring_documents AS
SELECT 
    uvd.id,
    uvd.user_id,
    u.email,
    dv.document_name,
    uvd.expiry_date,
    uvd.days_until_expiry,
    uvd.upload_status
FROM user_visa_documents uvd
JOIN users u ON uvd.user_id = u.id
JOIN document_vault dv ON uvd.document_vault_id = dv.id
WHERE uvd.expiry_date IS NOT NULL
    AND uvd.days_until_expiry <= 30
    AND uvd.days_until_expiry >= 0
    AND uvd.upload_status NOT IN ('expired', 'rejected');

COMMENT ON VIEW v_expiring_documents IS 'Documents expiring within 30 days';

-- View: User Points Summary
CREATE VIEW v_user_points_summary AS
SELECT 
    pc.user_id,
    u.email,
    vc.visa_subclass,
    pc.total_points,
    pc.age_points,
    pc.english_points,
    pc.overseas_experience_points,
    pc.australian_experience_points,
    pc.education_points,
    pc.australian_study_points,
    pc.regional_study_points,
    pc.professional_year_points,
    pc.ccl_points,
    pc.partner_points,
    pc.state_nomination_points,
    pc.calculated_at,
    CASE 
        WHEN vc.minimum_points_required IS NOT NULL AND pc.total_points >= vc.minimum_points_required 
        THEN TRUE 
        ELSE FALSE 
    END AS meets_minimum_points
FROM points_calculator pc
JOIN users u ON pc.user_id = u.id
LEFT JOIN visa_catalogue vc ON pc.visa_subclass_id = vc.id
WHERE pc.is_current = TRUE;

COMMENT ON VIEW v_user_points_summary IS 'Current points summary for all users';

-- =============================================================================
-- SCHEMA COMPLETE
-- =============================================================================
